//sends data at ~11 Mbps
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <math.h>
#include <arpa/inet.h>
#include <sys/socket.h>


#define DEST_PORT 25344
#define FRAME_SIZE 1028 //the total frame in number of bytes
#define NUM_SAMPLES 256 // 4 bytes being sent for each packet (1024/4)

//for fake data generation
#define SAMPLE_RATE (125e6 / 2560.0) // ~48.8 kHz
#define PHASE_WIDTH 27

int main(int argc, char *argv[]) {
    if (argc != 3) { //if the number of arguments passed is not equal to 3
        fprintf(stderr, "Usage: %s <target_ip> <num_packets>\n", argv[0]); //stderr is the standard terminal error message
        return 1;   //exit with status 1: error
    }

    const char *target_ip = argv[1]; //store the ip addr as a character array pointer
    int num_packets = atoi(argv[2]); //atoi converts a string into an integer, comes from stdlib

    int sock = socket(AF_INET, SOCK_DGRAM, 0); //creation of the socket, comes from sys/socket; AF_INET is domain parameter for IPv4; type User DataGRAM Protocol; picks defualt protocol for the specified
    if (sock < 0) { //if no socket 
        perror("socket");  // prints an error message followed by the system error discription
        return 1;   
    }

    struct sockaddr_in dest;
    memset(&dest, 0, sizeof(dest)); //fill a block of memory (socket address desitnation information) with all zeros; makes a known state
    dest.sin_family = AF_INET;      //sin_ is short for "socket internet IPv4"; family is IPv4
    dest.sin_port = htons(DEST_PORT);       //host to network short; converts to big endian; passing a little endian 16 bit port number
    if (inet_pton(AF_INET, target_ip, &dest.sin_addr) != 1) { //this line converts a string (target_ip) into a binary IPv4 address and stores the result into address memory location dest.sin_addr; checks if the result is true
        perror("inet_pton");    //there was a error - internet presentation to network
        close(sock);    //closes the socket since it was created earlier
        return 1;
    }

    uint8_t frame[FRAME_SIZE];      //create the frame array with size 1028 bytes

    //generate fake tone to simulate the FIFO read
    double freq = 1000.0;  // 1 kHz tone
    double phase = 0.0;
    double phase_inc = (freq / SAMPLE_RATE)*(1<<PHASE_WIDTH);  //(F_output/f_sys)*(2^Phase_width) = phase_inc
    
    printf("\r\n\r\n\r\n");
    

    for (uint32_t counter = 0; counter < (uint32_t)num_packets; counter++) { //Loop for the number of packets that we want to send
        // 4 byte counter; little endian achieved with bit masking
        frame[0] = counter & 0xFF;
        frame[1] = (counter >> 8) & 0xFF;
        frame[2] = (counter >> 16) & 0xFF;
        frame[3] = (counter >> 24) & 0xFF;

        // I/Q samples  -  generation of the reset of the data frame to transmit
        for (int n = 0; n < NUM_SAMPLES; n++) {

            //generating fake FIFO data here
            int16_t I = (int16_t)(sin(phase) * 30000);
            int16_t Q = (int16_t)(cos(phase) * 30000);
            phase += phase_inc;
            if (phase > 2.0 * M_PI) phase -= 2.0 * M_PI;
            //replace when we read data from fifo

            int offset = 4 + n * 4; // offset due to the 4 byte counter and recursive 4 byte (32 bit) packets of data
            // shift and mask data to achieve little endian
            frame[offset + 0] = I & 0xFF;
            frame[offset + 1] = (I >> 8) & 0xFF;
            frame[offset + 2] = Q & 0xFF;
            frame[offset + 3] = (Q >> 8) & 0xFF;
        }

        //ssize_t is signed version of size_t; size_t is used to measure sizes of memory block arrays and is usually 32 or 64 bit; using this to catch measurement error -1 if it occurs
        ssize_t sent = sendto(sock, frame, FRAME_SIZE, 0,       //send on this socket, with this data, data of this size, normal send flag, 
                              (struct sockaddr *)&dest, sizeof(dest));  // send to this desitnation addr, pass the size of the desination address so the kernal knows how many bytes to read for the address
        if (sent != FRAME_SIZE) {   // with success it will return the number of bytes sent
            perror("sendto");       //if not all the bytes were sent then send error essage to console
            break;
        }
        
        printf("Sent Packet %u (%zd bytes)\n", counter, sent);   //daig logging; sent this many packets; %zd is for size_t formating

        // Optional pacing (~5ms between frames)
        //usleep(5000);
        //computers should never sleep ;)
    }

    close(sock); //finished with the socket now release it/clean up
    return 0;
}