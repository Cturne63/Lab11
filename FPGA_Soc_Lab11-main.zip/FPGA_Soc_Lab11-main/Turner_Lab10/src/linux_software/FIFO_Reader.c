#include <stdio.h>
#include <sys/mman.h> 
#include <fcntl.h> 
#include <unistd.h>
#include <stdint.h>
#include <stdlib.h>
#include <time.h>

#define RADIO_TUNER_FAKE_ADC_PINC_OFFSET 0 
#define RADIO_TUNER_TUNER_PINC_OFFSET 1
#define RADIO_TUNER_CONTROL_REG_OFFSET 2    //bit <1> enables the FIFO Data register clock and wills tart sampling data
#define RADIO_TUNER_TIMER_REG_OFFSET 3
#define RADIO_PERIPH_ADDRESS 0x43c00000

#define FIFO_DATA_REG_STATUS_OFFSET 0 //<1> empty flag; <2> tvalid_o; <3> tready_o
#define FIFO_DATA_REG_READ_OFFSET 1 
#define FIFO_DATA_REG_RDCNT_OFFSET 2
#define FIFO_DATA_REG_WRCNT_OFFSET 3
#define FIFO_DATA_REG_ADDRESS   0x43c10000


uint32_t* FIFO_BUFFER = NULL; 

volatile unsigned int * get_a_pointer(unsigned int phys_addr)
{

	int mem_fd = open("/dev/mem", O_RDWR | O_SYNC); 
	void *map_base = mmap(0, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd, phys_addr); 
	volatile unsigned int *radio_base = (volatile unsigned int *)map_base; 
	return (radio_base);
}



void ReadFullFIFO(uint32_t FifoReadCount, uint32_t* ptrToFifoBuffer, volatile unsigned int *ptrToFIFO) {
    free(FIFO_BUFFER); //if prior use free the heap for more of this memory
    uint32_t*FIFO_BUFFER = (uint32_t*)malloc(FifoReadCount * sizeof(uint32_t)); //create a data pointer in heap memory; 

    for (int i = 0; i < FifoReadCount; i++) {
        FIFO_BUFFER[i] = *(ptrToFIFO+FIFO_DATA_REG_READ_OFFSET);
        //uint32_t writecnt = *(ptrToFIFO+FIFO_DATA_REG_WRCNT_OFFSET);  //for debug only
        //printf("Read Counter: %d Write Counter: %d: Data word %x \n", i, writecnt, FIFO_BUFFER[i]);    //for debug only

    }
}


int main()
{
    // first, get a pointer to the peripheral base address using /dev/mem and the function mmap
    volatile unsigned int *radio_periph = get_a_pointer(RADIO_PERIPH_ADDRESS);	    
    volatile unsigned int *fifo_periph = get_a_pointer(FIFO_DATA_REG_ADDRESS);	
    
    printf("\r\n\r\n\r\nhello I am going to read 10 seconds worth of data now\n");
    *(radio_periph+RADIO_TUNER_FAKE_ADC_PINC_OFFSET) = 1000;    //set the frequency for the radio and output the data
    *(radio_periph+RADIO_TUNER_CONTROL_REG_OFFSET) = 1;      //enable the clock for the fifo and begin the capture

    while ((0x00000100 & *(fifo_periph+FIFO_DATA_REG_STATUS_OFFSET)) == 0);    //do nothing and wait for the fifo to full flag to set; mask the data and only look at the full flag
    //while ( *(fifo_periph+FIFO_DATA_REG_RDCNT_OFFSET) != 1024); //now do nothing until the fifo is completely full

    //gives ~480_000 samples of data
    for (int j = 0; j < 469; j++) {
        uint32_t ReadCount = *(fifo_periph+FIFO_DATA_REG_RDCNT_OFFSET);
        ReadFullFIFO(ReadCount, FIFO_BUFFER, fifo_periph);
        while ((0x00000100 & *(fifo_periph+FIFO_DATA_REG_STATUS_OFFSET)) == 0); //wait for the fifo to fill up before preforming the read again
    }

    printf("Finished!\n");

    *(radio_periph+RADIO_TUNER_FAKE_ADC_PINC_OFFSET) = 0; //disable the fifo and no output on the radio
    *(radio_periph+RADIO_TUNER_CONTROL_REG_OFFSET) = 0;

    return 0;
}
