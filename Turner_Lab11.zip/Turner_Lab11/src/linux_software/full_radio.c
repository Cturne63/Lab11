#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h> 
#include <sys/socket.h>
#include <fcntl.h> 
#include <arpa/inet.h>

#define RADIO_TUNER_FAKE_ADC_PINC_OFFSET 0 
#define RADIO_TUNER_TUNER_PINC_OFFSET 1
#define RADIO_TUNER_CONTROL_REG_OFFSET 2    //bit <1> enables the FIFO Data register clock and wills tart sampling data
#define RADIO_TUNER_TIMER_REG_OFFSET 3
#define RADIO_PERIPH_ADDRESS 0x43c00000

#define OPERATING_FREQ      125000000 //dds sys clk
#define PHASE_WIDTH         27

uint32_t* FIFO_BUFFER = NULL; 

volatile unsigned int * get_a_pointer(unsigned int phys_addr)
{

	int mem_fd = open("/dev/mem", O_RDWR | O_SYNC); 
	void *map_base = mmap(0, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd, phys_addr); 
	volatile unsigned int *radio_base = (volatile unsigned int *)map_base; 
	return (radio_base);
}

uint32_t setfrequency (uint32_t frequency) {
    if (frequency > (OPERATING_FREQ)) {
        printf("No Frquency Loaded - Invalid Frequency\n\r");
        return 0;
    }

    //F_output = fs * (phase_inc / 2^N)
    //print("Updating Frequency:\n\r");
    //printf("Frequency    = %d\n\r", frequency);

    //(F_output/f_sys)*(2^Phase_width) = phase_inc
    uint32_t phase_inc = (uint32_t)(((uint64_t)frequency << PHASE_WIDTH) / OPERATING_FREQ);  //this is the same as F_output*(2^Phase_width) only using bit shifting instead multiplicaiton. cased to u64 to prevent overflow then divided by the operating frequency
    printf("Phase Increment = %d\n\r", phase_inc);

    return phase_inc;

}

int main(int argc, char *argv[])
{
    // first, get a pointer to the peripheral base address using /dev/mem and the function mmap
    volatile unsigned int *radio_periph = get_a_pointer(RADIO_PERIPH_ADDRESS);	    

    if (argc != 4) { //if the number of arguments passed is not equal to 5 Arg[0]is the program
        fprintf(stderr, "Usage: %s <ADC_Freq_Hz> <Tune_Freq_Hz> <Enable UFP Stream>\n", argv[0]); //stderr is the standard terminal error message
        return 1;   //exit with status 1: error
    }

    //configuring the radio
    uint32_t adc_freq = (uint32_t)atoi(argv[1]); //atoi converts a string into an integer, comes from stdlib
    uint32_t tune_freq = (uint32_t)atoi(argv[2]);
    int streaming_flag = atoi(argv[3]);
    *(radio_periph+RADIO_TUNER_FAKE_ADC_PINC_OFFSET) = setfrequency(adc_freq);    //set the frequency for the ADC
    *(radio_periph+RADIO_TUNER_TUNER_PINC_OFFSET) = setfrequency(tune_freq);        //set the frequency for the Tunning

    //set clock the fifo with data; else disable the fifo and udp streaming
    if (streaming_flag == 1) {
        *(radio_periph+RADIO_TUNER_CONTROL_REG_OFFSET) = 1;         //enable the clock for the fifo and begin the capture
    }
    else {
        *(radio_periph+RADIO_TUNER_CONTROL_REG_OFFSET) = 0;         //disable the clock for the fifo and capture
    }

    return 0;
}
