#! /usr/bin/python3
import cgi, cgitb
import sys
import subprocess

# Create instance of FieldStorage
form = cgi.FieldStorage()

# Get data from fields
adc_freq_hz  = int(form.getvalue('adc_freq_hz'))
tune_freq_hz  = int(form.getvalue('tune_freq_hz'))
streaming = form.getvalue('streaming')

# Send the result to the browser
print ("Content-type:text/html")
print()
print ("<html>")
print ('<head>')
print ("<title>Radio Configurator</title>")
print ('</head>')
print ('<body>')
print ("<h2>Radio Configurator</h2>")
print ("Setting up the radio now...")
print ("ADC Freq = %d, Tune Freq = %d" %(adc_freq_hz,tune_freq_hz))
#if (streaming == "streaming"):
#    print ("streaming is Enabled<br>")
#else :
#    print ("streaming is Disabled<br>")

# Call the C executable with parameters
try:
    # Convert streaming checkbox to 1 or 0
    streaming_flag = "1" if streaming == "streaming" else "0"
    
    # Call your executable 
    result = subprocess.run(
        ['./full_radio', str(adc_freq_hz), str(tune_freq_hz), streaming_flag],
        capture_output=True,
        text=True,
        timeout=10  # 10 second timeout
    )
    
    # Display the output from your C program
    if result.returncode == 0:
        print ("Configuration successful!<br>")
        if result.stdout:
            print ("<pre>" + result.stdout + "</pre>")
    else:
        print ("Configuration failed!<br>")
        if result.stderr:
            print ("<pre>Error: " + result.stderr + "</pre>")
    
    if streaming == "streaming":
        print ("Streaming is Enabled<br>")
    else:
        print ("Streaming is Disabled<br>")
        
except subprocess.TimeoutExpired:
    print ("Error: Configuration took too long (timeout)<br>")
except Exception as e:
    print (f"Error: {str(e)}<br>")


print ('</body>')
print ('</html>')

