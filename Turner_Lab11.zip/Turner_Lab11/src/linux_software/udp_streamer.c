#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h> 
#include <sys/socket.h>
#include <fcntl.h> 
#include <arpa/inet.h>
#include <signal.h>

#define FIFO_DATA_REG_STATUS_OFFSET 0 //<1> empty flag; <2> tvalid_o; <3> tready_o
#define FIFO_DATA_REG_READ_OFFSET 1 //data read register
#define FIFO_DATA_REG_RDCNT_OFFSET 2  //number of words avaliable to read
#define FIFO_DATA_REG_WRCNT_OFFSET 3
#define FIFO_DATA_REG_ADDRESS   0x43c10000

#define DEST_PORT 25344
#define FRAME_SIZE 1028 // 4 bytes counter + 1024 bytes data
#define NUM_SAMPLES 256 // 256 samples * 4 bytes = 1024 bytes

volatile unsigned int * get_a_pointer(unsigned int phys_addr) {
    int mem_fd = open("/dev/mem", O_RDWR | O_SYNC); 
    void *map_base = mmap(0, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, mem_fd, phys_addr); 
    volatile unsigned int *radio_base = (volatile unsigned int *)map_base; 
    return (radio_base);
}

void ReadFullFIFO(uint32_t FifoReadCount, uint32_t* ptrToFifoBuffer, volatile unsigned int *ptrToFIFO) {
    for (int i = 0; i < FifoReadCount; i++) {
        ptrToFifoBuffer[i] = *(ptrToFIFO+FIFO_DATA_REG_READ_OFFSET);
    }
}

int main(int argc, char *argv[]) {

    if (argc != 2) {
        fprintf(stderr, "Usage: %s <Target_IP_Addr>\n", argv[0]);
        return 1;
    }

    // Configuring the streamer ip and fifo
    const char *target_ip = argv[1];
    volatile unsigned int *fifo_periph = get_a_pointer(FIFO_DATA_REG_ADDRESS);	

    // Set up of the socket for streaming UDP data
    printf("Setting up UDP streaming to %s:%d\n", target_ip, DEST_PORT);

    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        perror("socket");
        return 1;   
    }

    struct sockaddr_in dest;
    memset(&dest, 0, sizeof(dest));
    dest.sin_family = AF_INET;
    dest.sin_port = htons(DEST_PORT);
    if (inet_pton(AF_INET, target_ip, &dest.sin_addr) != 1) {
        perror("inet_pton");
        close(sock);
        return 1;
    }

    // Allocate buffer for FIFO data (256 samples * 4 bytes = 1024 bytes)
    uint32_t *FIFO_BUFFER = (uint32_t*)malloc(NUM_SAMPLES * sizeof(uint32_t));
    if (FIFO_BUFFER == NULL) {
        perror("malloc");
        close(sock);
        return 1;
    }

    uint8_t frame[FRAME_SIZE]; // 4 bytes counter + 1024 bytes data = 1028 bytes
    uint32_t packet_counter = 0;

    // Wait for the FIFO to be full before starting; check bit 8 of the fifo status register
    while ((0x00000100 & *(fifo_periph+FIFO_DATA_REG_STATUS_OFFSET)) == 0);

    while (1) {
        uint32_t ReadCount = *(fifo_periph+FIFO_DATA_REG_RDCNT_OFFSET);
        
        // Read FIFO data into buffer
        ReadFullFIFO(ReadCount, FIFO_BUFFER, fifo_periph);

        // Build the frame: 4-byte counter + 1024 bytes of FIFO data; used memcpy to copy a block of memory from one location to another
        memcpy(frame, &packet_counter, 4);              // First 4 bytes: counter
        memcpy(frame + 4, FIFO_BUFFER, 1024);           // Next 1024 bytes: FIFO data

        // Send the frame
        ssize_t sent = sendto(sock, frame, FRAME_SIZE, 0,
                            (struct sockaddr *)&dest, sizeof(dest));

        if (sent != FRAME_SIZE) {
            perror("sendto");
            break;
        }

        packet_counter++; // Increment counter for next packet

        // Wait for the FIFO to fill up before performing the read again
        while ((0x00000100 & *(fifo_periph+FIFO_DATA_REG_STATUS_OFFSET)) == 0);
    }
    
    
    //clean up
    close(sock);
    free(FIFO_BUFFER);

    return 0;
}